from flask import Flask, render_template, request
import random
import string
import pyotp
import datetime
app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index7.html')




vowels = 'aeiou'
consonants = ''.join(set(string.ascii_lowercase) - set(vowels))

DEFAULT_EXPIRATION_DAYS = 90
password_history = []


def generate_password(length, characters):
    password = ''
    for i in range(length):
        password += random.choice(characters)
    password_history.append((password, datetime.datetime.now()))
    return password


def password_strength(password):
    score = 0
    length = len(password)
    uppercase = False
    lowercase = False
    digit = False
    special = False
    if length >= 8:
        score += 1
    if length >= 12:
        score += 1
    if any(c.isupper() for c in password):
        uppercase = True
        score += 1
    if any(c.islower() for c in password):
        lowercase = True
        score += 1
    if any(c.isdigit() for c in password):
        digit = True
        score += 1
    if any(c in '!@#$%^&*()_+-=[]{}|\\:;"<>,.?/' for c in password):
        special = True
        score += 1
    if uppercase and lowercase and digit and special:
        score += 1
    return score


def generate_pronounceable_password(length=10):
    password = ''
    for i in range(length):
        if i % 2 == 0:
            password += random.choice(consonants)
        else:
            password += random.choice(vowels)
    return password


def generate_password_with_expiration(length=10, expiration_days=DEFAULT_EXPIRATION_DAYS):
    password = generate_pronounceable_password(length)
    expiration_date = datetime.date.today() + datetime.timedelta(days=expiration_days)
    return (password, expiration_date)


def generate_multilingual_password(length=10, languages=['en']):
    password = ''
    for i in range(length):
        language = random.choice(languages)
        if language == 'en':
            password += random.choice(string.ascii_letters)
        elif language == 'zh':
            password += chr(random.randint(0x4e00, 0x9fff))
        elif language == 'ja':
            password += chr(random.randint(0x3040, 0x30ff))
        else:
            password += random.choice(string.printable)
    return password 
    return render_template('password_generator.html', password=password)


def generate_otp_secret():
    return pyotp.random_base32()


def verify_otp(secret, code):
    totp = pyotp.TOTP(secret)
    return totp.verify(code)
