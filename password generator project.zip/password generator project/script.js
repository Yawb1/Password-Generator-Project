function generatePassword(length, characters) {
    const lowercase = 'abcdefghijklmnopqrstuvwxyz';
    const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const numbers = '0123456789';
    const symbols = '!@#$%^&*()_+-=[]{}|;:\'",./<>?\\~`';
    let chars = '';
    
    if (characters === 'letters') {
      chars += lowercase + uppercase;
    } else if (characters === 'alphanumeric') {
      chars += lowercase + uppercase + numbers;
    } else if (characters === 'special') {
      chars += symbols;
    } else {
      chars += lowercase + uppercase + numbers + symbols;
    }
  
    let password = '';
  
    for (let i = 0; i < length; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
  
    return password;
  }
  
  const form = document.querySelector('form');
  const passwordDisplay = document.querySelector('#password');
  
  form.addEventListener('submit', function(event) {
    event.preventDefault();
    const length = document.querySelector('#length').value;
    const characters = document.querySelector('#characters').value;
    const password = generatePassword(length, characters);
    passwordDisplay.innerText = password;
  });
  